Below is the github link:

https://github.com/NadirAnwar/NLP_Tweet_Classification

The pdf file is in A0 format so please zoom in to have a clear vision